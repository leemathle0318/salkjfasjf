# OBS Audio Entry Probe 0.1.0：独立观察式音频入口诊断

## 目的

用户8 Plus/iOS15.0.2/rootless/Dopamine：OBSBridge0.2.8画面已可用；苹果相机录制含OBS音轨与环境音；TikTok直播说话正常、OBS音轨缺失且有杂音。不能由相机录制成功推断直播一定使用同一采集通路。

本包只定位采集入口，不混音、不解决发热/真实画面回退，也不把诊断计数叫作直播修复成功。独立包ID local.xiaoguai.obsbridge.audio-probe，和现有OBS Bridge同时安装；不覆盖它的模块、设置、缓存或libSandy授权。

## 观察哪些实际调用

- AudioUnitRender：只将Apple输出I/O组件RemoteIO或VoiceProcessingIO、bus1、返回成功且有非零帧/缓冲列表的调用记为已确认类型的输入。bus0另记为输出；bus1但类型不明另记，避免误选播放/变换节点。
- 创建/初始化/格式配置期间缓存组件类型和原生ASBD；render回调只计数、读取元数据并原样转发，不在里面查格式、写磁盘或展开调用栈。单位最多32个，超出会报告。
- AVAudioInputNode：仅观察应用已请求的input tap回调；不主动安装新采集tap、不打开新麦克风会话。
- AVCaptureAudioDataOutput：观察实际音频委托回调，不把“设置了委托”当作“真的采到音频”。最多8种委托类，检查标准CMSampleBuffer参数签名后才观察；回调参数/返回/音频样本均不修改。
- 记录格式、位深、采样率、通道、帧数、次数、最近活动时间和App版本。**不读取PCM样本值、不复制或保存音频，不发送到网络。** 观察式hook仍有开销和兼容风险，不承诺绝对零影响。

苹果公开资料：[AudioUnitRender](https://developer.apple.com/documentation/audiotoolbox/audiounitrender(_:_:_:_:_:_:))、[输入回调属性](https://developer.apple.com/documentation/audiotoolbox/kaudiooutputunitproperty_setinputcallback)、[VoiceProcessingIO输入/输出总线](https://developer.apple.com/documentation/audiotoolbox/kaudiounitsubtype_voiceprocessingio)、[输入节点tap示例](https://developer.apple.com/videos/play/wwdc2021/10045/)。

TikTok目标BundleID com.zhiliaoapp.musically 已通过Apple公开lookup核对（2026-10-12）；这不代表用户安装的TikTok版本等于App Store当前版本。改包标识、TikTok Lite或其他应用不在当前过滤范围，不能用零计数认定没有采集。

## GitHub构建

建议用单独仓库，避免替换已经工作的OBS工作流。

1. 上传 `OBSAudioProbe-source-0.1.0.zip` 原文件。
2. 新建工作流文件 `.github/workflows/build-audio-probe.yml`，把“GitHub工作流-OBSAudioProbe只读诊断.txt”的完整内容粘贴进去，提交。
3. Actions选择 **Build OBS Audio Entry Probe**，手动Run workflow。此工作流只手动触发，不自动编译主OBS插件，不需要FFmpeg。
4. 构建成功后下载 **OBS-Audio-Probe-deb** 内的deb。不是OBSBridge更新包，不要卸载0.2.8。

## 手机只需一次诊断

1. 用Sileo安装诊断deb，按安装提示注销SpringBoard一次，让报告模块加载；不要为了此包重装OBS/libSandy或反复重启用户空间。
2. 强制关闭后重新打开TikTok，让探针从应用启动观察。现有OBS按原有方式接收；如果注销中断了SB接收，重新开始接收即可，电脑参数不用改。
3. TikTok普通页面停留约5秒，再进入实际直播并保持说话10–15秒。页面预览或普通相机录制不能替代这段直播状态。
4. 用Filza打开并分享整个文件：

   `/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.audio-probe.plist`

   不用手抄错误码或所有字段。文件保留最近15个2秒窗口，包含时间/新心跳/PID/累计计数与增长量；切到Filza若TikTok挂起，文件会保留近期记录并标过期，不会继续装作活跃。
5. 如只发截图，拍Summary、History中的最新几个窗口、LastInputEntry、格式和HookMask。诊断文件本身通常更有用。
6. 发完结果可从Sileo卸载 **OBS Audio Entry Probe**，保留 **OBS Bridge**。停止/卸载不保证自动清理报告；需要时只删上述诊断plist，别删主插件配置或媒体缓存。

## 如何判定

- 直播期间VoiceIO_Delta持续增长：实际观察到VoiceProcessingIO输入调用。
- RemoteIO_Delta持续增长：实际观察到RemoteIO输入调用。
- InputTap_Delta增长：输入节点tap正在投递。
- AVCaptureAudio_Delta增长：采集音频委托正在投递。
- 仅OutputBus0_Delta增长不是麦克风输入；仅有注册次数也不算采集证据。
- HookMask仅表示观察入口已挂接，不能单凭它判定直播音源。
- 无新心跳：可能应用未加载探针/挂起/通知受限/包标识不同。零输入计数：也可能采用未覆盖的接口。不要由这些直接得出“手机没声音”或乱选函数。
- LastInputEntry/格式是最后观察结果，必须结合LastInputAge与近2秒Delta读；格式全零表示未取得格式，不代表真实采样率为0。

**持续采集是候选入口证据，不独立证明该缓冲最终送入直播编码器。** 若多个入口都活跃，要结合普通页→直播阶段变化进一步核对，不能直接在所有输入/输出回调里混音。

## 验证与限制

已做两个iOS arm64对象编译、输入分类/心跳过期/PID计数重置策略测试、5项源码检查、6项合成包检查和工作流/ZIP校验。完整Theos链接签名、arm64e、iOS实际hook/通知/报告写入以及TikTok实时调用尚无手机通过记录。

没有隐藏注入、绕过应用保护、关闭直播降噪或调整AVAudioSession；没有读取认证信息、麦克风内容或上传诊断。报告只有元数据且手机文件设为0600，不过Darwin通知不作为保密/认证渠道。完成诊断后卸载，避免长期运行。诊断版不保证消除杂音、OBS缺声或发热。
