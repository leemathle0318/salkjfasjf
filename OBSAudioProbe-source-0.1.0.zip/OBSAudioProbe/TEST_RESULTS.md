# 本机检查记录（2026-10-12）

- 最终AudioProbe.mm、ProbeObserver.mm在SDK16.5/deploy15/ARC/blocks/Wall/Wextra/Werror下生成arm64 iOS Mach-O对象。
- 纯C++策略测试：输入必须是Apple输出I/O组件+bus1+成功调用；排除bus0/错误/转换器/未知组件；计数回退/PID变化不产生假增长；6000ms旧心跳拒绝，32位时间回绕可处理。
- 5项源码结构检查，包括单App/SB过滤、不读PCM/不写原样本、不在render回调查格式/写日志、不混音、原参数转发、原子文件报告/限长历史/新鲜状态。
- 6项合成deb检查：完整四文件/限定过滤、双架构、root属主和不可组写/他人写、拒绝主OBS模块混入、截断失败。合成包绝不可安装。
- ZIP校验和工作流YAML/Bash/嵌入Python解析；实际源码定位的完整/改名/新旧源码共存/缺项/危险路径/换行案例检查。
- 原OBSBridge-source-0.2.8.zip SHA256仍dbbdc603381be96b1aff8087fa2fc2e94942f7ffcbb81e65a8e723a0ea4bef5b；此包未修改主插件。

未完成：完整macOS Theos链接/签名、arm64e、手机MSHookFunction/ObjC观察、通知权限和报告写入、真实TikTok音频路径确认。只读是“不修改音频/不读取内容”的观察方式，不保证无性能开销或任何App兼容性。
