# 本机检查记录（2026-10-12）

- 最终AudioProbe.mm、ProbeObserver.mm在SDK16.5/deploy15/ARC/blocks/Wall/Wextra/Werror下生成arm64 iOS Mach-O对象。
- 纯C++策略测试：输入必须是Apple输出I/O组件+bus1+成功调用；排除bus0/错误/转换器/未知组件；计数回退/PID变化不产生假增长；6000ms旧心跳拒绝，32位时间回绕可处理。
- 7项源码结构检查，包括单App/SB过滤、不读PCM/不写原样本、不在render回调查格式/写日志、不混音、原参数转发、原子文件报告/限长历史/新鲜状态。
- 6项合成deb检查：完整四文件/限定过滤、双架构、root属主和不可组写/他人写、拒绝主OBS模块混入、截断失败。合成包绝不可安装。
- ZIP校验和工作流YAML/Bash/嵌入Python解析；实际源码定位的完整/改名/新旧源码共存/缺项/危险路径/换行案例检查。
- 原OBSBridge-source-0.2.8.zip SHA256仍dbbdc603381be96b1aff8087fa2fc2e94942f7ffcbb81e65a8e723a0ea4bef5b；此包未修改主插件。

未完成：完整macOS Theos链接/签名、arm64e、手机MSHookFunction/ObjC观察、通知权限和报告写入、真实TikTok音频路径确认。只读是“不修改音频/不读取内容”的观察方式，不保证无性能开销或任何App兼容性。

## 源码检查范围修正（2026-10-12）

用户GitHub在Diagnostic policy and package checks阶段失败。旧test_unix扫描整个目录，把刚编译的work/probe-policy Mach-O也当成文本检查CR，断言又把二进制全部打印出来。

本机将实际iOS Mach-O放到与CI相同的work/probe-policy位置，旧检查确实失败，错误输出471591字节；不删除该二进制，仅替换修正后的检查，同一目录7项源码测试通过。新增生成物排除及真实源码CRLF/BOM必须失败的回归，错误只显示文件名，不打印原始缓冲。

只修改检查范围与错误提示，没有跳过源码检查、改探针功能或改OBSBridge0.2.8。编译产物、.theos、packages、vendor、.git、__pycache__不是源码文本；真正源码与打包文本仍检查。工作流本身不用替换，只替换仓库中同名OBSAudioProbe-source-0.1.0.zip，提交后开始新运行（不要重跑旧提交）。完整Theos构建和手机探针运行仍未确认。
