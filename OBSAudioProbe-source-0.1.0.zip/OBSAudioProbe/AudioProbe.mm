#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import <CoreMedia/CoreMedia.h>
#import <substrate.h>
#import <objc/runtime.h>
#include <mach/mach_time.h>
#include <notify.h>
#include <unistd.h>
#include <dlfcn.h>
#include <array>
#include <atomic>
#include <algorithm>
#include <utility>
#include <cstring>
#include <cmath>
#include "ProbeShared.h"
#include "core/ProbePolicy.hpp"

namespace {
static_assert(probe::fourcc('r','i','o','c')==kAudioUnitSubType_RemoteIO, "RemoteIO component identity");
static_assert(probe::fourcc('v','p','i','o')==kAudioUnitSubType_VoiceProcessingIO, "VoiceProcessingIO identity");
static_assert(std::atomic<uint64_t>::is_always_lock_free, "real-time counters must be lock-free");
std::array<std::atomic<uint64_t>,probe::Count> values{};
double millisecondsPerTick=0;
uint64_t nowMS() { return uint64_t(mach_absolute_time()*millisecondsPerTick); }
struct Unit {
    std::atomic<uintptr_t> address{0};
    std::atomic<uint32_t> type{0}, subtype{0}, manufacturer{0};
    std::atomic<uint64_t> format{0}, layout{0}, rate{0};
};
std::array<Unit,32> units;
Unit *find(AudioUnit unit) {
    auto key=reinterpret_cast<uintptr_t>(unit);
    for (auto &slot:units) if (slot.address.load(std::memory_order_acquire)==key) return &slot;
    return nullptr;
}
uint64_t layout(const AudioStreamBasicDescription &f) {
    return (uint64_t(f.mBitsPerChannel&65535)<<48)|(uint64_t(f.mChannelsPerFrame&65535)<<32)|f.mBytesPerFrame;
}
uint64_t rate(const AudioStreamBasicDescription &f) {
    return std::isfinite(f.mSampleRate) && f.mSampleRate>=0 && f.mSampleRate<=192000 ? uint64_t(f.mSampleRate) : 0;
}
void updateFormat(Unit &slot,const AudioStreamBasicDescription &f) {
    slot.format.store((uint64_t(f.mFormatID)<<32)|f.mFormatFlags);
    slot.layout.store(layout(f));slot.rate.store(rate(f));
}
void registerUnit(AudioUnit unit) {
    if (!unit) return;
    Unit *slot=find(unit);
    if (!slot) for (auto &entry:units) {
        uintptr_t empty=0;
        if (entry.address.compare_exchange_strong(empty,1)) {
            entry.type=0;entry.subtype=0;entry.manufacturer=0;entry.format=0;entry.layout=0;entry.rate=0;
            entry.address.store(reinterpret_cast<uintptr_t>(unit),std::memory_order_release);slot=&entry;break;
        }
    }
    if (!slot) { ++values[probe::RegistryOverflow];return; }
    // Runs on create/initialize/configuration, never in the render hook.
    AudioComponentDescription description{};
    AudioComponent component=AudioComponentInstanceGetComponent(unit);
    if (component && !AudioComponentGetDescription(component,&description)) {
        slot->type=description.componentType;slot->subtype=description.componentSubType;
        slot->manufacturer=description.componentManufacturer;
    }
    AudioStreamBasicDescription f{};UInt32 bytes=sizeof(f);
    if (!AudioUnitGetProperty(unit,kAudioUnitProperty_StreamFormat,kAudioUnitScope_Output,1,&f,&bytes) && bytes==sizeof(f))
        updateFormat(*slot,f);
}
void noteInput(probe::Entry entry,UInt32 frames,uint64_t format,uint64_t nativeLayout,uint64_t sampleRate) {
    values[probe::Format]=format;values[probe::Layout]=nativeLayout;
    values[probe::RateFrames]=(sampleRate<<32)|frames;
    values[probe::LastEntry]=entry;values[probe::LastInputMS]=nowMS();
}
using Render=OSStatus(*)(AudioUnit,AudioUnitRenderActionFlags*,const AudioTimeStamp*,UInt32,UInt32,AudioBufferList*);
using NewUnit=OSStatus(*)(AudioComponent,AudioComponentInstance*);
using Dispose=OSStatus(*)(AudioComponentInstance);
using Initialize=OSStatus(*)(AudioUnit);
using SetProperty=OSStatus(*)(AudioUnit,AudioUnitPropertyID,AudioUnitScope,AudioUnitElement,const void*,UInt32);
Render originalRender=nullptr;NewUnit originalNew=nullptr;Dispose originalDispose=nullptr;
Initialize originalInitialize=nullptr;SetProperty originalProperty=nullptr;
thread_local unsigned renderDepth=0;
OSStatus render(AudioUnit unit,AudioUnitRenderActionFlags *flags,const AudioTimeStamp *time,UInt32 bus,UInt32 frames,AudioBufferList *data) {
    ++renderDepth;
    OSStatus rc=originalRender(unit,flags,time,bus,frames,data);
    bool top=renderDepth--==1;
    if (!top) return rc;
    if (rc) { ++values[probe::RenderErrors];return rc; }
    if (bus==0) { ++values[probe::Output];return rc; }
    if (bus!=1) return rc;
    if (!frames || !data || !data->mNumberBuffers) return rc;
    auto *slot=find(unit);
    unsigned kind=slot ? probe::inputKind(slot->type.load(),slot->subtype.load(),slot->manufacturer.load(),bus,rc) : 0;
    if (!kind) { ++values[probe::UnknownInput];return rc; }
    ++values[kind==1 ? probe::RemoteInput : probe::VoiceInput];
    noteInput(kind==1 ? probe::RemoteIO : probe::VoiceIO,frames,slot->format.load(),slot->layout.load(),slot->rate.load());
    // Never inspect, copy, mix, zero or modify data/flags/time.
    return rc;
}
OSStatus create(AudioComponent component,AudioComponentInstance *unit) {
    OSStatus rc=originalNew(component,unit);if (!rc && unit) registerUnit(*unit);return rc;
}
OSStatus dispose(AudioComponentInstance unit) {
    auto *slot=find(unit);OSStatus rc=originalDispose(unit);
    if (!rc && slot) slot->address.store(0,std::memory_order_release);return rc;
}
OSStatus initialize(AudioUnit unit) {
    OSStatus rc=originalInitialize(unit);if (!rc) registerUnit(unit);return rc;
}
OSStatus property(AudioUnit unit,AudioUnitPropertyID id,AudioUnitScope scope,AudioUnitElement element,const void *data,UInt32 size) {
    OSStatus rc=originalProperty(unit,id,scope,element,data,size);
    if (!rc && id==kAudioOutputUnitProperty_SetInputCallback) ++values[probe::InputRegistered];
    if (!rc && id==kAudioUnitProperty_StreamFormat) registerUnit(unit);
    return rc;
}
template<class F> bool hook(const char *name,F replacement,F &original,unsigned bit) {
    void *symbol=dlsym(RTLD_DEFAULT,name);if (!symbol) return false;
    MSHookFunction(symbol,reinterpret_cast<void *>(replacement),reinterpret_cast<void **>(&original));
    if (!original) return false;
    values[probe::Hooks].fetch_or(uint64_t(1)<<bit);return true;
}

using Delivery=void(*)(id,SEL,AVCaptureOutput*,CMSampleBufferRef,AVCaptureConnection*);
struct DelegateSlot { Class cls=Nil;std::atomic<Delivery> original{nullptr}; };
std::array<DelegateSlot,8> delegates;
unsigned delegateCount=0;
template<size_t I> void deliver(id object,SEL cmd,AVCaptureOutput *output,CMSampleBufferRef sample,AVCaptureConnection *connection) {
    Delivery call=delegates[I].original.load(std::memory_order_acquire);
    if (!call) return;
    auto format=sample ? CMSampleBufferGetFormatDescription(sample) : nullptr;
    if (format && CMFormatDescriptionGetMediaType(format)==kCMMediaType_Audio) {
        ++values[probe::CaptureInput];
        const auto *f=CMAudioFormatDescriptionGetStreamBasicDescription(format);
        CMItemCount frames=CMSampleBufferGetNumSamples(sample);
        if (f) noteInput(probe::CaptureDelegate,frames>0 && frames<=UINT32_MAX ? UInt32(frames) : 0,
            (uint64_t(f->mFormatID)<<32)|f->mFormatFlags,layout(*f),rate(*f));
    }
    call(object,cmd,output,sample,connection);
}
template<size_t... I> auto deliveries(std::index_sequence<I...>) { return std::array<IMP,sizeof...(I)>{reinterpret_cast<IMP>(deliver<I>)...}; }
NSObject *delegateLock;
void watchDelegate(id delegate) {
    if (!delegate) return;
    @synchronized(delegateLock) {
        Class cls=object_getClass(delegate);SEL selector=@selector(captureOutput:didOutputSampleBuffer:fromConnection:);
        for (unsigned i=0;i<delegateCount;++i) if (delegates[i].cls==cls) return;
        Method method=class_getInstanceMethod(cls,selector);
        if (!method || method_getNumberOfArguments(method)!=5 || delegateCount>=delegates.size()) return;
        char type[8]{};method_getReturnType(method,type,sizeof(type));if (strcmp(type,"v")) return;
        char sampleType[256]{};method_getArgumentType(method,3,sampleType,sizeof(sampleType));
        if (sampleType[0]!='^' || !strstr(sampleType,"CMSampleBuffer")) return;
        unsigned index=delegateCount++;delegates[index].cls=cls;
        auto fallback=reinterpret_cast<Delivery>(method_getImplementation(method));
        delegates[index].original.store(fallback,std::memory_order_release);
        static const auto replacements=deliveries(std::make_index_sequence<8>{});
        Delivery previous=nullptr;MSHookMessageEx(cls,selector,replacements[index],reinterpret_cast<IMP *>(&previous));
        delegates[index].original.store(previous ?: fallback,std::memory_order_release);
    }
}
using SetDelegate=void(*)(id,SEL,id,dispatch_queue_t);SetDelegate originalDelegate=nullptr;
void setDelegate(id object,SEL selector,id delegate,dispatch_queue_t queue) {
    watchDelegate(delegate);++values[probe::CaptureRegistered];originalDelegate(object,selector,delegate,queue);
}
using InstallTap=void(*)(id,SEL,AVAudioNodeBus,AVAudioFrameCount,AVAudioFormat*,AVAudioNodeTapBlock);
InstallTap originalTap=nullptr;
void installTap(id object,SEL selector,AVAudioNodeBus bus,AVAudioFrameCount size,AVAudioFormat *format,AVAudioNodeTapBlock block) {
    ++values[probe::TapRegistered];
    if (!block) { originalTap(object,selector,bus,size,format,block);return; }
    AVAudioNodeTapBlock wrapped=^(AVAudioPCMBuffer *buffer,AVAudioTime *time) {
        ++values[probe::TapInput];
        const auto *f=buffer.format.streamDescription;
        if (f) noteInput(probe::InputTap,buffer.frameLength,(uint64_t(f->mFormatID)<<32)|f->mFormatFlags,layout(*f),rate(*f));
        block(buffer,time);
    };
    // Wrap only an already requested input-node tap; never install a new one.
    originalTap(object,selector,bus,size,format,wrapped);
}
std::array<int,probe::Count> tokens;
dispatch_source_t timer;
void publish() {
    static uint64_t sequence=0;
    auto put=[](unsigned field,uint64_t value) {
        if (tokens[field]<0 && notify_register_check(probe::names[field],&tokens[field])!=NOTIFY_STATUS_OK) { tokens[field]=-1;return uint32_t(1); }
        return notify_set_state(tokens[field],value);
    };
    uint32_t error=put(probe::Sequence,++sequence);
    for (unsigned i=1;i<probe::Count;++i) {
        uint64_t v=i==probe::Heart ? (uint64_t(getpid())<<32)|uint32_t(nowMS()) : values[i].load();
        error|=put(i,v);
    }
    error|=put(probe::Sequence,++sequence);
    static uint32_t lastError=0;
    if (error && error!=lastError) NSLog(@"[OBSAudioProbe] metadata publication blocked rc=%u; zero counters do not establish no capture",error);
    lastError=error;
}
}
__attribute__((constructor)) static void startProbe() {
    @autoreleasepool {
        if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.zhiliaoapp.musically"]) return;
        mach_timebase_info_data_t base{};mach_timebase_info(&base);millisecondsPerTick=double(base.numer)/base.denom/1000000;
        delegateLock=[NSObject new];tokens.fill(-1);
        hook("AudioUnitRender",render,originalRender,0);
        hook("AudioComponentInstanceNew",create,originalNew,1);
        hook("AudioComponentInstanceDispose",dispose,originalDispose,2);
        hook("AudioUnitInitialize",initialize,originalInitialize,3);
        hook("AudioUnitSetProperty",property,originalProperty,4);
        Class capture=objc_getClass("AVCaptureAudioDataOutput");
        if (capture && class_getInstanceMethod(capture,@selector(setSampleBufferDelegate:queue:))) {
            MSHookMessageEx(capture,@selector(setSampleBufferDelegate:queue:),reinterpret_cast<IMP>(setDelegate),reinterpret_cast<IMP *>(&originalDelegate));
            if (originalDelegate) values[probe::Hooks].fetch_or(uint64_t(1)<<5);
        }
        Class input=objc_getClass("AVAudioInputNode");SEL selector=@selector(installTapOnBus:bufferSize:format:block:);
        if (input && class_getInstanceMethod(input,selector)) {
            MSHookMessageEx(input,selector,reinterpret_cast<IMP>(installTap),reinterpret_cast<IMP *>(&originalTap));
            if (originalTap) values[probe::Hooks].fetch_or(uint64_t(1)<<6);
        }
        NSString *version=NSBundle.mainBundle.infoDictionary[@"CFBundleShortVersionString"];
        NSArray *parts=[version componentsSeparatedByString:@"."];
        uint64_t encoded=0;for (unsigned i=0;i<std::min<size_t>(parts.count,3);++i) encoded|=uint64_t([parts[i] intValue]&65535)<<(32-i*16);
        values[probe::AppVersion]=encoded;
        NSLog(@"[OBSAudioProbe] %@ entered TikTok %@; diagnostic only, no PCM content",PROBE_VERSION,version);
        timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_global_queue(QOS_CLASS_UTILITY,0));
        dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,0),2*NSEC_PER_SEC,NSEC_PER_SEC/4);
        dispatch_source_set_event_handler(timer,^{ @autoreleasepool { publish(); } });dispatch_resume(timer);
    }
}
