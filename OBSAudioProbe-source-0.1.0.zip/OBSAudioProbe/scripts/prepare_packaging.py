import argparse, hashlib
from pathlib import Path

DM_SHA256 = "a750fda6e9a2306b6c2b8b099e21aeca56b314179c0cd3b73c7c8636b32f5d41"
OLD = b'$tf->chown("root", "wheel");'
NEW = OLD + b'\n\t\t\t\t\t# OBSBridge: numeric owners must agree with the root/wheel names.\n\t\t\t\t\t$tf->uid(0);\n\t\t\t\t\t$tf->gid(0);'


def patch_dm(path, expected_hash=DM_SHA256):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError("Theos dm.pl must be a regular file")
    raw = path.read_bytes()
    if NEW in raw:
        original = raw.replace(NEW, OLD)
        if raw.count(NEW) != 1 or hashlib.sha256(original).hexdigest() != expected_hash:
            raise ValueError("unexpected already-patched Theos dm.pl")
        return False
    if hashlib.sha256(raw).hexdigest() != expected_hash or raw.count(OLD) != 1:
        raise ValueError("unsupported Theos dm.pl: expected pinned submodule d9a3b72e274226dd2823c0a7c1d6d05099f4f51c")
    path.write_bytes(raw.replace(OLD, NEW))
    return True


if __name__ == "__main__":
    parser=argparse.ArgumentParser();parser.add_argument('--patch-theos',required=True);args=parser.parse_args()
    try:
        print('Theos numeric owner patch:',patch_dm(args.patch_theos))
    except (ValueError,OSError) as error:
        raise SystemExit(str(error))
