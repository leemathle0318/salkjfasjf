#import <Foundation/Foundation.h>
#include <mach/mach_time.h>
#include <notify.h>
#include <unistd.h>
#include <sys/stat.h>
#include <array>
#include <algorithm>
#include "ProbeShared.h"
#include "core/ProbePolicy.hpp"

namespace {
std::array<int,probe::Count> tokens;
std::array<uint64_t,probe::Count> previous{};
NSMutableArray *history;
dispatch_source_t timer;
double millisecondsPerTick=0;
bool previouslyFresh=false, wroteInitial=false;
uint64_t nowMS() { return uint64_t(mach_absolute_time()*millisecondsPerTick); }
uint32_t read(unsigned field,uint64_t &value) {
    value=0;
    if (tokens[field]<0 && notify_register_check(probe::names[field],&tokens[field])!=NOTIFY_STATUS_OK) {tokens[field]=-1;return 1;}
    return notify_get_state(tokens[field],&value);
}
NSString *fourcc(uint32_t value) {
    char text[5]{};for (unsigned i=0;i<4;++i) {unsigned c=(value>>(24-i*8))&255;text[i]=c>=32 && c<=126 ? char(c) : '?';}
    return [NSString stringWithUTF8String:text];
}
void report() {
    std::array<uint64_t,probe::Count> state{};
    uint32_t error=0;bool complete=false;
    for (unsigned attempt=0;attempt<2 && !complete;++attempt) {
        uint64_t before=0,after=0;error=read(probe::Sequence,before);
        if (error || (before&1)) continue;
        for (unsigned i=1;i<probe::Count;++i) error|=read(i,state[i]);
        error|=read(probe::Sequence,after);
        complete=!error && before==after && !(after&1);
    }
    uint64_t now=nowMS();bool fresh=complete && probe::fresh(state[probe::Heart],now);
    if (wroteInitial && !fresh && !previouslyFresh) return; // no constant disk writes while TikTok is closed
    bool same=fresh && previouslyFresh && (state[probe::Heart]>>32)==(previous[probe::Heart]>>32);
    auto changed=[&](probe::Field field) {return probe::delta(previous[field],state[field],same);};
    NSString *summary;
    if (error) summary=@"通知读取失败；不能用零计数判断音频入口";
    else if (!complete) summary=@"探针发布尚未完成；等待下一次快照";
    else if (!fresh) summary=@"未收到新TikTok探针心跳（未注入/应用已停止或挂起/通知受限）；不能认定没有音频";
    else if (!same) summary=@"已收到TikTok探针心跳；等待下一个2秒窗口比较回调增长";
    else if (changed(probe::VoiceInput)) summary=@"近2秒有VoiceProcessingIO麦克风输入bus 1成功回调；已观察到候选实时采集入口";
    else if (changed(probe::RemoteInput)) summary=@"近2秒有RemoteIO麦克风输入bus 1成功回调；已观察到候选实时采集入口";
    else if (changed(probe::TapInput)) summary=@"近2秒有AVAudioInputNode输入tap实际回调；已观察到候选采集入口";
    else if (changed(probe::CaptureInput)) summary=@"近2秒有AVCapture音频委托实际回调；已观察到候选采集入口";
    else if (changed(probe::UnknownInput)) summary=@"有bus 1回调，但组件类型未确认；不能仅凭bus号认定麦克风";
    else summary=@"近2秒未看到已覆盖输入接口的新回调；可能未采集或采用未覆盖接口，不能盲选入口";
    NSDictionary *sample=@{@"Date":[NSDate date],@"PID":@(uint32_t(state[probe::Heart]>>32)),@"Fresh":@(fresh),
        @"RemoteIO_InputCalls":@(state[probe::RemoteInput]),@"VoiceIO_InputCalls":@(state[probe::VoiceInput]),
        @"InputTapCalls":@(state[probe::TapInput]),@"AVCaptureAudioCalls":@(state[probe::CaptureInput]),
        @"RemoteIO_Delta":@(changed(probe::RemoteInput)),@"VoiceIO_Delta":@(changed(probe::VoiceInput)),
        @"InputTap_Delta":@(changed(probe::TapInput)),@"AVCaptureAudio_Delta":@(changed(probe::CaptureInput)),
        @"UnknownBus1_Delta":@(changed(probe::UnknownInput)),@"OutputBus0_Delta":@(changed(probe::Output)),
        @"Summary":summary};
    if (!history) history=[NSMutableArray new];[history addObject:sample];if (history.count>15) [history removeObjectAtIndex:0];
    uint64_t fmt=state[probe::Format],nativeLayout=state[probe::Layout],version=state[probe::AppVersion];
    unsigned entry=unsigned(state[probe::LastEntry]);
    NSArray *entryNames=@[@"尚无已确认输入",@"RemoteIO input bus1",@"VoiceProcessingIO input bus1",@"未知AudioUnit",
        @"AVAudioInputNode tap",@"AVCapture音频委托"];
    NSString *age=state[probe::LastInputMS] ? [NSString stringWithFormat:@"%.3f秒",double(now>=state[probe::LastInputMS] ? now-state[probe::LastInputMS] : 0)/1000] : @"未观察到";
    NSDictionary *document=@{@"ProbeVersion":PROBE_VERSION,@"Date":[NSDate date],@"Summary":summary,
        @"ExpectedBundleID":@"com.zhiliaoapp.musically",@"TikTokVersion":[NSString stringWithFormat:@"%u.%u.%u",unsigned(version>>32),unsigned((version>>16)&65535),unsigned(version&65535)],
        @"PID":@(uint32_t(state[probe::Heart]>>32)),@"FreshHeartbeat":@(fresh),@"NotificationError":@(error),
        @"HookMask":@(state[probe::Hooks]),@"RemoteIO_InputCalls":@(state[probe::RemoteInput]),
        @"VoiceIO_InputCalls":@(state[probe::VoiceInput]),@"UnknownBus1Calls":@(state[probe::UnknownInput]),
        @"OutputBus0Calls":@(state[probe::Output]),@"RenderErrors":@(state[probe::RenderErrors]),
        @"InputTapCalls":@(state[probe::TapInput]),@"AVCaptureAudioCalls":@(state[probe::CaptureInput]),
        @"InputCallbackRegistrations":@(state[probe::InputRegistered]),@"TapRegistrations":@(state[probe::TapRegistered]),
        @"CaptureDelegateRegistrations":@(state[probe::CaptureRegistered]),@"RegistryOverflow":@(state[probe::RegistryOverflow]),
        @"LastInputEntry":entry<entryNames.count ? entryNames[entry] : @"未知",@"LastInputAge":age,
        @"Format":fourcc(uint32_t(fmt>>32)),@"FormatFlags":@(uint32_t(fmt)),@"Bits":@(nativeLayout>>48),
        @"Channels":@((nativeLayout>>32)&65535),@"BytesPerFrame":@(uint32_t(nativeLayout)),
        @"SampleRate":@(state[probe::RateFrames]>>32),@"Frames":@(uint32_t(state[probe::RateFrames])),
        @"History":history,@"Limit":@"只记录接口/格式/次数，不读取PCM内容；候选采集入口仍需与直播阶段和推流链路核对"};
    struct stat info{};
    if (!lstat(PROBE_REPORT.fileSystemRepresentation,&info) && (!S_ISREG(info.st_mode) || info.st_nlink!=1 || info.st_uid!=geteuid())) {
        NSLog(@"[OBSAudioProbe] refused unsafe existing diagnostic path");return;
    }
    NSError *failure=nil;
    NSData *data=[NSPropertyListSerialization dataWithPropertyList:document format:NSPropertyListXMLFormat_v1_0 options:0 error:&failure];
    if (!data || ![data writeToFile:PROBE_REPORT options:NSDataWritingAtomic error:&failure]) {
        NSLog(@"[OBSAudioProbe] could not write report: %@",failure.localizedDescription);return;
    }
    chmod(PROBE_REPORT.fileSystemRepresentation,0600);
    previous=state;previouslyFresh=fresh;wroteInitial=true;
}
}
__attribute__((constructor)) static void startObserver() {
    @autoreleasepool {
        mach_timebase_info_data_t base{};mach_timebase_info(&base);millisecondsPerTick=double(base.numer)/base.denom/1000000;
        tokens.fill(-1);auto queue=dispatch_queue_create("local.xiaoguai.obsbridge.audio-probe.report",DISPATCH_QUEUE_SERIAL);
        timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,queue);
        dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,0),2*NSEC_PER_SEC,NSEC_PER_SEC/4);
        dispatch_source_set_event_handler(timer,^{@autoreleasepool {report();}});dispatch_resume(timer);
    }
}
