#pragma once
#include <cstdint>
#include <cstddef>
#define PROBE_VERSION @"0.1.0"
#define PROBE_REPORT @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.audio-probe.plist"
namespace probe {
enum Field : unsigned { Sequence, Heart, Hooks, RemoteInput, VoiceInput, UnknownInput, Output,
    RenderErrors, TapInput, CaptureInput, InputRegistered, LastInputMS, Format, Layout,
    RateFrames, LastEntry, RegistryOverflow, AppVersion, CaptureRegistered, TapRegistered, Count };
enum Entry : unsigned { None, RemoteIO, VoiceIO, UnknownAU, InputTap, CaptureDelegate };
static constexpr const char *names[] = {
    "local.xiaoguai.obsbridge.audio-probe.sequence", "local.xiaoguai.obsbridge.audio-probe.heart",
    "local.xiaoguai.obsbridge.audio-probe.hooks", "local.xiaoguai.obsbridge.audio-probe.remote",
    "local.xiaoguai.obsbridge.audio-probe.voice", "local.xiaoguai.obsbridge.audio-probe.unknown",
    "local.xiaoguai.obsbridge.audio-probe.output", "local.xiaoguai.obsbridge.audio-probe.errors",
    "local.xiaoguai.obsbridge.audio-probe.tap", "local.xiaoguai.obsbridge.audio-probe.capture",
    "local.xiaoguai.obsbridge.audio-probe.input-registered", "local.xiaoguai.obsbridge.audio-probe.last-input",
    "local.xiaoguai.obsbridge.audio-probe.format", "local.xiaoguai.obsbridge.audio-probe.layout",
    "local.xiaoguai.obsbridge.audio-probe.rate-frames", "local.xiaoguai.obsbridge.audio-probe.entry",
    "local.xiaoguai.obsbridge.audio-probe.overflow", "local.xiaoguai.obsbridge.audio-probe.app-version",
    "local.xiaoguai.obsbridge.audio-probe.capture-registered", "local.xiaoguai.obsbridge.audio-probe.tap-registered"
};
static_assert(sizeof(names)/sizeof(names[0])==Count, "telemetry field count");
}
