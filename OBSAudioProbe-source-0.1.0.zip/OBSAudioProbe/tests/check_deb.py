"""Check actual .deb payloads, not just source-tree files. No extraction to disk."""
import io
import plistlib
import struct
import sys
import tarfile
from pathlib import Path, PurePosixPath


def payload(path, with_metadata=False):
    raw = Path(path).read_bytes()
    if raw[:8] != b"!<arch>\n":
        raise ValueError("not a Debian ar archive")
    offset = 8
    result = {}
    metadata = {}
    while offset < len(raw):
        header = raw[offset:offset + 60]
        if len(header) != 60 or header[-2:] != b"`\n":
            raise ValueError("invalid ar header")
        name = header[:16].decode("ascii").strip().rstrip("/")
        size = int(header[48:58])
        start = offset + 60
        if start + size > len(raw):
            raise ValueError("truncated ar member")
        if name.startswith("data.tar"):
            with tarfile.open(fileobj=io.BytesIO(raw[start:start + size])) as archive:
                for member in archive.getmembers():
                    if not member.isfile():
                        continue
                    key = PurePosixPath(member.name).as_posix().removeprefix("./")
                    result[key] = archive.extractfile(member).read()
                    metadata[key] = (member.uid, member.gid, member.mode)
        offset = start + size + size % 2
    return (result, metadata) if with_metadata else result


def check(path):
    files,metadata=payload(path,with_metadata=True)
    prefix='var/jb/Library/MobileSubstrate/DynamicLibraries/'
    for module,bundle in [('OBSAudioProbe','com.zhiliaoapp.musically'),('OBSAudioProbeObserver','com.apple.springboard')]:
        binary=prefix+module+'.dylib';rule=prefix+module+'.plist'
        if binary not in files or rule not in files: raise ValueError('missing probe module '+module)
        if plistlib.loads(files[rule]).get('Filter') != {'Bundles':[bundle]}: raise ValueError('wrong scoped filter')
        for name in (binary,rule):
            uid,gid,mode=metadata[name]
            if uid or gid or mode&0o022: raise ValueError('unsafe owner/mode '+name)
        raw=files[binary]
        if len(raw)<8 or raw[:4]!=b'\xca\xfe\xba\xbe': raise ValueError('expected universal Mach-O')
        count=struct.unpack_from('>I',raw,4)[0];archs=set()
        if count>8 or 8+count*20>len(raw): raise ValueError('invalid Mach-O table')
        for i in range(count):
            cpu,subtype,start,size,align=struct.unpack_from('>5I',raw,8+i*20)
            if start+size>len(raw) or raw[start:start+4]!=b'\xcf\xfa\xed\xfe': raise ValueError('bad slice')
            archs.add((cpu,subtype&0xffffff))
        if not {(0x100000c,0),(0x100000c,2)}<=archs: raise ValueError('missing arm64/arm64e')
        if b'local.xiaoguai.obsbridge.audio-probe.remote' not in raw: raise ValueError('missing metadata protocol')
    if any('OBSBridge.' in name or 'libSandy/' in name for name in files): raise ValueError('probe must not replace main OBS plugin or alter sandbox grants')
    return len(files)
if __name__=='__main__':
    for name in sys.argv[1:]:
        try: print('PASS: scoped diagnostic package',name,check(name),'files')
        except (OSError,ValueError,struct.error,tarfile.TarError) as error: raise SystemExit('PROBE PACKAGE CHECK FAILED: '+str(error))
