from pathlib import Path
import plistlib,unittest,tempfile,sys
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
GENERATED_DIRS={'.git','.theos','work','packages','vendor','__pycache__'}
TEXT_SUFFIXES={'.h','.hpp','.c','.cc','.cpp','.m','.mm','.py','.yml','.yaml','.md','.plist','.sh','.txt'}
TEXT_NAMES={'Makefile','control','LICENSE','.gitattributes','.gitignore'}
def source_text_files(root):
    for path in root.rglob('*'):
        if not path.is_file() or any(part in GENERATED_DIRS for part in path.relative_to(root).parts):
            continue
        if path.name in TEXT_NAMES or path.suffix.lower() in TEXT_SUFFIXES:
            yield path
class SourceTest(unittest.TestCase):
    def test_scope(self):
        for name,bundle in [('OBSAudioProbe','com.zhiliaoapp.musically'),('OBSAudioProbeObserver','com.apple.springboard')]:
            self.assertEqual(plistlib.loads((ROOT/(name+'.plist')).read_bytes())['Filter'],{'Bundles':[bundle]})
        self.assertIn('Package: local.xiaoguai.obsbridge.audio-probe',(ROOT/'control').read_text())
        self.assertNotIn('libsandy',(ROOT/'control').read_text().lower())
    def test_no_pcm_contents(self):
        text=(ROOT/'AudioProbe.mm').read_text(encoding='utf-8')
        for forbidden in ('mBuffers[','floatChannelData','int16ChannelData','CMSampleBufferGetDataBuffer','CMSampleBufferGetAudioBufferList','memcpy(','readAudio(','mixNative(','writeToFile','backtrace('):
            self.assertNotIn(forbidden,text)
        self.assertIn('probe::inputKind',text);self.assertIn('call(object,cmd,output,sample,connection)',text)
        self.assertIn('block(buffer,time)',text);self.assertIn('originalRender(unit,flags,time,bus,frames,data)',text)
        render=text.split('OSStatus render(',1)[1].split('OSStatus create(',1)[0]
        self.assertNotIn('AudioUnitGetProperty',render);self.assertNotIn('NSLog',render)
    def test_report(self):
        text=(ROOT/'ProbeObserver.mm').read_text(encoding='utf-8')
        self.assertIn('probe::fresh',text);self.assertIn('probe::delta',text)
        self.assertIn('history.count>15',text);self.assertIn('0600',text)
        self.assertIn('before==after',text);self.assertIn('NSDataWritingAtomic',text)
    def test_unix(self):
        for path in source_text_files(ROOT):
            label=path.relative_to(ROOT).as_posix()
            with self.subTest(path=label):
                raw=path.read_bytes()
                # Boolean assertions avoid dumping whole source/binary buffers.
                self.assertFalse(b'\r' in raw,'CRLF/CR in source text: '+label)
                self.assertFalse(raw.startswith(b'\xef\xbb\xbf'),'UTF-8 BOM in source text: '+label)
    def test_generated_binaries_are_not_source_text(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            for name in ('work/probe-policy','.theos/obj/sample.o','packages/sample.deb','vendor/include/generated.h','__pycache__/sample.pyc','binary.exe'):
                path=root/name;path.parent.mkdir(parents=True,exist_ok=True)
                path.write_bytes(b'\xcf\xfa\xed\xfe\x00\r\xff')
            (root/'core').mkdir();(root/'core/sample.cpp').write_bytes(b'int value=0;\n')
            (root/'control').write_bytes(b'Package: source\n')
            self.assertEqual({p.relative_to(root).as_posix() for p in source_text_files(root)}, {'core/sample.cpp','control'})
            with patch.object(sys.modules[__name__],'ROOT',root):
                SourceTest('test_unix').test_unix()
    def test_real_source_crlf_and_bom_still_fail(self):
        for raw in (b'int value=0;\r\n',b'\xef\xbb\xbfint value=0;\n'):
            with tempfile.TemporaryDirectory() as folder:
                root=Path(folder);(root/'sample.cpp').write_bytes(raw)
                with patch.object(sys.modules[__name__],'ROOT',root):
                    with self.assertRaises(AssertionError) as failure:
                        SourceTest('test_unix').test_unix()
                    self.assertLess(len(str(failure.exception)),256)
    def test_complete(self):
        for name in ('AudioProbe.mm','ProbeObserver.mm','ProbeShared.h','core/ProbePolicy.hpp','tests/probe_policy_tests.cpp','scripts/prepare_packaging.py'):
            self.assertTrue((ROOT/name).is_file(),name)
if __name__=='__main__':unittest.main(verbosity=2)
