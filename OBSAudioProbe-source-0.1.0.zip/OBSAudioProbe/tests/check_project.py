from pathlib import Path
import plistlib,unittest
ROOT=Path(__file__).resolve().parents[1]
class SourceTest(unittest.TestCase):
    def test_scope(self):
        for name,bundle in [('OBSAudioProbe','com.zhiliaoapp.musically'),('OBSAudioProbeObserver','com.apple.springboard')]:
            self.assertEqual(plistlib.loads((ROOT/(name+'.plist')).read_bytes())['Filter'],{'Bundles':[bundle]})
        self.assertIn('Package: local.xiaoguai.obsbridge.audio-probe',(ROOT/'control').read_text())
        self.assertNotIn('libsandy',(ROOT/'control').read_text().lower())
    def test_no_pcm_contents(self):
        text=(ROOT/'AudioProbe.mm').read_text(encoding='utf-8')
        for forbidden in ('mBuffers[','floatChannelData','int16ChannelData','CMSampleBufferGetDataBuffer','CMSampleBufferGetAudioBufferList','memcpy(','readAudio(','mixNative(','writeToFile','backtrace('):
            self.assertNotIn(forbidden,text)
        self.assertIn('probe::inputKind',text);self.assertIn('call(object,cmd,output,sample,connection)',text)
        self.assertIn('block(buffer,time)',text);self.assertIn('originalRender(unit,flags,time,bus,frames,data)',text)
        render=text.split('OSStatus render(',1)[1].split('OSStatus create(',1)[0]
        self.assertNotIn('AudioUnitGetProperty',render);self.assertNotIn('NSLog',render)
    def test_report(self):
        text=(ROOT/'ProbeObserver.mm').read_text(encoding='utf-8')
        self.assertIn('probe::fresh',text);self.assertIn('probe::delta',text)
        self.assertIn('history.count>15',text);self.assertIn('0600',text)
        self.assertIn('before==after',text);self.assertIn('NSDataWritingAtomic',text)
    def test_unix(self):
        for path in ROOT.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts:
                raw=path.read_bytes();self.assertNotIn(b'\r',raw,str(path));self.assertFalse(raw.startswith(b'\xef\xbb\xbf'))
    def test_complete(self):
        for name in ('AudioProbe.mm','ProbeObserver.mm','ProbeShared.h','core/ProbePolicy.hpp','tests/probe_policy_tests.cpp','scripts/prepare_packaging.py'):
            self.assertTrue((ROOT/name).is_file(),name)
if __name__=='__main__':unittest.main(verbosity=2)
