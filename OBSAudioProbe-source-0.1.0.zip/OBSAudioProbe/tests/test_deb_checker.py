"""Synthetic fixtures only; never install."""
import io,plistlib,struct,tarfile,tempfile,unittest
from pathlib import Path
from check_deb import check

def macho(archs=(0, 2), markers=b"BWNodeOutput\0emitSampleBuffer:\0local.xiaoguai.obsbridge.receive\0local.xiaoguai.obsbridge.media-v4.dat\0libSandy_applyProfile\0local.xiaoguai.obsbridge.v4.audio.phase\0"):
    offset = 8 + len(archs) * 20
    headers = []
    slices = []
    for subtype in archs:
        data = struct.pack("<8I", 0xfeedfacf, 0x100000c, subtype, 6, 0, 0, 0, 0) + markers
        headers.append(struct.pack(">5I", 0x100000c, subtype, offset, len(data), 0))
        slices.append(data)
        offset += len(data)
    return b"\xca\xfe\xba\xbe" + struct.pack(">I", len(archs)) + b"".join(headers + slices)


def files():
    prefix='var/jb/Library/MobileSubstrate/DynamicLibraries/'
    result={}
    for module,bundle in [('OBSAudioProbe','com.zhiliaoapp.musically'),('OBSAudioProbeObserver','com.apple.springboard')]:
        result[prefix+module+'.dylib']=macho(markers=b'local.xiaoguai.obsbridge.audio-probe.remote\0')
        result[prefix+module+'.plist']=plistlib.dumps({'Filter':{'Bundles':[bundle]}},fmt=plistlib.FMT_BINARY)
    return result


def package(items, metadata=None):
    data = io.BytesIO()
    with tarfile.open(fileobj=data, mode="w:gz") as archive:
        for name, content in items.items():
            member = tarfile.TarInfo(name)
            member.size = len(content)
            if metadata and name in metadata:
                member.uid, member.gid, member.mode = metadata[name]
            archive.addfile(member, io.BytesIO(content))
    def ar(name, content):
        header = f"{name + '/':<16}{0:<12}{0:<6}{0:<6}{'100644':<8}{len(content):<10}`\n".encode("ascii")
        return header + content + (b"\n" if len(content) % 2 else b"")
    return b"!<arch>\n" + ar("debian-binary", b"2.0\n") + ar("data.tar.gz", data.getvalue())

class PackageTest(unittest.TestCase):
    def run_check(self,raw):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'synthetic-never-install.deb';path.write_bytes(raw);return check(path)
    def test_valid(self): self.assertEqual(self.run_check(package(files())),4)
    def test_wrong_filter(self):
        items=files();items['var/jb/Library/MobileSubstrate/DynamicLibraries/OBSAudioProbe.plist']=plistlib.dumps({'Filter':{'Bundles':['*']}})
        with self.assertRaisesRegex(ValueError,'filter'):self.run_check(package(items))
    def test_missing_and_old(self):
        items=files();key='var/jb/Library/MobileSubstrate/DynamicLibraries/OBSAudioProbe.dylib'
        with self.assertRaisesRegex(ValueError,'missing'):self.run_check(package({k:v for k,v in items.items() if k!=key}))
        items[key]=macho((2,),markers=b'local.xiaoguai.obsbridge.audio-probe.remote')
        with self.assertRaisesRegex(ValueError,'arm64'):self.run_check(package(items))
    def test_permissions(self):
        key='var/jb/Library/MobileSubstrate/DynamicLibraries/OBSAudioProbe.dylib'
        for attrs in ((501,0,0o644),(0,501,0o644),(0,0,0o666)):
            with self.assertRaisesRegex(ValueError,'owner'):self.run_check(package(files(),{key:attrs}))
    def test_no_main_plugin(self):
        items=files();items['var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridge.dylib']=b'forbidden'
        with self.assertRaisesRegex(ValueError,'main OBS'):self.run_check(package(items))
    def test_truncated(self):
        with self.assertRaises(ValueError):self.run_check(package(files())[:-17])
if __name__=='__main__':unittest.main(verbosity=2)
