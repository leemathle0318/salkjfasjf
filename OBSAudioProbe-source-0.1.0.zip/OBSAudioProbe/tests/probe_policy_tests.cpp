#ifdef NDEBUG
#undef NDEBUG
#endif
#include "../core/ProbePolicy.hpp"
#include <cassert>
#include <cstdio>
int main() {
    using namespace probe;
    auto output=fourcc('a','u','o','u'),apple=fourcc('a','p','p','l'),remote=fourcc('r','i','o','c'),voice=fourcc('v','p','i','o');
    assert(inputKind(output,remote,apple,1,0)==1);assert(inputKind(output,voice,apple,1,0)==2);
    assert(!inputKind(output,remote,apple,0,0));assert(!inputKind(output,remote,apple,1,-1));
    assert(!inputKind(fourcc('a','u','f','c'),remote,apple,1,0));assert(!inputKind(output,remote,0,1,0));
    assert(!inputKind(output,0,apple,1,0));
    assert(delta(10,50,true)==40);assert(delta(50,10,true)==0);assert(delta(10,50,false)==0);
    assert(fresh((uint64_t(123)<<32)|10000,12000));assert(!fresh((uint64_t(123)<<32)|10000,16000));
    assert(!fresh(0,0));assert(fresh((uint64_t(123)<<32)|0xfffffff0u,uint64_t(0x100000020)));
    std::puts("PASS: capture requires Apple I/O component + bus1 + successful call; output/error/converter excluded; PID/counter reset and stale-heartbeat rejection (not device API test)");
}
