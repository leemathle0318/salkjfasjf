#pragma once
#include <cstdint>
namespace probe {
constexpr uint32_t fourcc(char a,char b,char c,char d) {
    return (uint32_t(uint8_t(a))<<24)|(uint32_t(uint8_t(b))<<16)|(uint32_t(uint8_t(c))<<8)|uint8_t(d);
}
// Bus 1 alone is not sufficient: require an Apple output I/O component.
inline unsigned inputKind(uint32_t type,uint32_t subtype,uint32_t manufacturer,unsigned bus,int status) {
    if (status || bus!=1 || type!=fourcc('a','u','o','u') || manufacturer!=fourcc('a','p','p','l')) return 0;
    return subtype==fourcc('r','i','o','c') ? 1 : subtype==fourcc('v','p','i','o') ? 2 : 0;
}
inline bool fresh(uint64_t heartbeat,uint64_t nowMS) {
    return uint32_t(heartbeat>>32)!=0 && uint32_t(uint32_t(nowMS)-uint32_t(heartbeat))<6000;
}
inline uint64_t delta(uint64_t before,uint64_t after,bool sameProcess) {
    return sameProcess && after>=before ? after-before : 0;
}
}
